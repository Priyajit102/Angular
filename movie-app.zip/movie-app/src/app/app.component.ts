import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'parent-child';
  // name = 'strm';
  // salary = 45000000;
  // isadmin = true;
  // age = 50.5;

  // getFullName() {
  //   alert('pubg');
  // }

  // // add(x: number, y: number) {
  // //   alert(x + y);
  // // }

  // c: number = 0;
  // add(x: number, y: number) {
  //   this.c = x + y;
  //   alert(this.c);
  // }
  // getName(x: string) {
  //   this.name = x;
  // }
  // abcd = '';
  // chngName(x: string) {
  //   // this.abcd = x ? x : 'Please input somthing';
  //   x === '' ? (this.abcd = 'Please input somthing') : (this.abcd = x);
  // }
// move = 0;
//   moveCount(){
//     this.move++;
//   }
//   over=0;
  
//   overCount(){
//     this.over++;
//   }
//   enter=0;
  
//   enterCount(){
//     this.enter++;
//   }

// value= '';
// placeholder='';
//   chngName(x: string, y: string){
   
//     this.value ===''?this.value='Enter Something': this.value;
//     this.placeholder = y;


//   }

// isValue = 'Angular';
// isReadonly=true;
// isDisabled= true;
// isPassout= false;


// displayCond: boolean = true;
// MakeTrue(x: number){
//   this.displayCond = x=== 1 ? true: false;
// }

// num:number = 0;
// num1:number = 0;
// items: item[] = [
//   { name: 'One', val: 1 },
//   { name: 'Two', val: 2 },
//   { name: 'Three', val: 3 },
//   { name: 'Four', val: 3 },
//   { name: 'Five', val: 3 },
// ];
// selectedValue1: string = 'One';

// }
// class item{
//   name:string| undefined;
//   val: number | undefined;

// num20:number = 10;




movies: Movie[] = [
  {
    title: 'Zootopia',
    img: 'https://images-na.ssl-images-amazon.com/images/S/pv-target-images/0ecb745d03d6656e19c12acc7fe9f7a7ba6336a0f2d2c202aff94a8335f00aae._RI_V_TTW_.jpg',
    director: 'Byron Howard, Rich Moore',
    cast: 'Idris Elba, Ginnifer Goodwin, Jason Bateman',
    releaseDate: 'March 4, 2016',
  },
  {
    title: 'Batman v Superman: Dawn of Justice',
    img: 'https://m.media-amazon.com/images/M/MV5BYThjYzcyYzItNTVjNy00NDk0LTgwMWQtYjMwNmNlNWJhMzMyXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_.jpg',
    director: 'Zack Snyder',
    cast: 'Ben Affleck, Henry Cavill, Amy Adams',
    releaseDate: 'March 25, 2016',
  },
  {
    title: 'Captain American: Civil War',
    img: 'https://cf-images.us-east-1.prod.boltdns.net/v1/static/5359769168001/0a823cb0-01a9-4835-a348-c64187783ccb/d37cb96c-805c-4aa2-9f2f-e62d9eb814c7/1280x720/match/image.jpg',
    director: 'Anthony Russo, Joe Russo',
    cast: 'Scarlett Johansson, Elizabeth Olsen, Chris Evans',
    releaseDate: 'May 6, 2016',
  },
  {
    title: 'X-Men: Apocalypse',
    img: 'https://cdn.mos.cms.futurecdn.net/e6hWKhmXszRLNSvPRHizZ5.jpg',
    director: 'Bryan Singer',
    cast: 'Jennifer Lawrence, Olivia Munn, Oscar Isaac',
    releaseDate: 'May 27, 2016',
  },
  {
    title: 'Warcraft',
    img: 'https://m.media-amazon.com/images/I/81feWhChfIL._SL1500_.jpg',
    director: 'Duncan Jones',
    cast: 'Travis Fimmel, Robert Kazinsky, Ben Foster',
    releaseDate: 'June 10, 2016',
  },
];
}
class Movie{
title: string | undefined;
img: string | undefined;
director: string | undefined;
cast: string | undefined;
releaseDate: string | undefined;
}



































  



















